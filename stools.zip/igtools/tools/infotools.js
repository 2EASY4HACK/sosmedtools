//Changed by Putu Developers
const Client = require('instagram-private-api').V1;
const delay = require('delay');
const chalk = require('chalk');
const inquirer = require('inquirer');
var moment = require("moment");
var colors = require('colors');
var userHome = require('user-home');

console.log(chalk`{bold.green
Ξ TITLE  : [⚡] INFORMASI INSTAGRAM TOOLS [⚡]}`);

console.log(chalk`{bold.white
01. BomLikeTarget (LIKE/LOVE ALL MEDIA/POST USER)
02. Botlike1 (LIKE/LOVE TIMELINE INSTAGRAM)
03. Botlike2 (LIKE/LOVE TIMELINE INSTAGRAM)
04. Dellallphoto (DELETE ALL MEDIA/POST INSTAGRAM)
05. Fah (FOLLOW,LIKE,COMMENT TARGET HASTAG)
06. Fftauto (FOLLOW,LIKE,COMMENT TARGET FOLLOWER USER)
07. Flaauto (FOLLOW,LIKE,COMMENT TARGET LOCATION)
08. Flmauto (FOLLOW,LIKE,COMMENT TARGET MEDIA/POST)
09. Unfollall (UNFOLOW ALL FOLLOWING INSTAGRAM)
10. Unfollnotfollback(UNFOLLOW NOT FOLLOWBACK INSTAGRAM}`);

console.log(chalk`{yellow
Catatan!
Ini Hanya Informasi Tentang Tools Yang Ada Dalam Program ini.
Untuk Memulai Program, Anda Harus Menjalankan Kembali node index.js
Lalu Lansung Memilih Program Sesuai Informasi Tools Diatas.

Changed by Putu Developers - @officialputuid}`);